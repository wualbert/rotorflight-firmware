ROTORFLIGHT PARAMETER-JOURNAL HARDWARE EVIDENCE
4.6 BACKPORT, BLADES-OFF SPOOL-UP BENCH, 2026-10-16

Firmware: Rotorflight 4.6.0-bbp 58a4bd5cc, STM32G47X, MTKS-MATEKG474HELI.
58a4bd5cc = 874f369d5 (public branch blackbox-param-journal-bench-20261013)
with src/main/rx/spektrum.c restored to 4.6.0 (118e912). It is the 4.6
backport of the journal, not the PR head. src/main/blackbox differs from the
PR's production commit 85d7049a9 by 84 added and 31 removed lines (4.7 hooks
and style). These results apply to 58a4bd5cc.

Hardware: SAB Fireball, blades removed, battery power, governor spool-up to
5000-5470 rpm. ExpressLRS 4.1.0 CRSF at 500 Hz. Gain edits with the
transmitter Rotorflight Lua 2.3.0. blackbox_params FULL, 1 kHz logging.

RECORDING
logs/fireball-46bbp-blades-off-20261016.bbl: 20,301,824 bytes, the flash
bytes 6,625,280-26,927,104 (everything recorded in this session). The flash
before that offset holds earlier recordings and is not included. Two
independent USB reads of this range are byte-identical.

  log 0  header only, 18,432 bytes, no frames, no LOG_END (see below)
  log 1  100,340 frames, armed 0-95.9 s
  log 2  169,770 frames, armed 0-0.09 s, disarmed by the switch, armed again
         at 0.36 s in the grace period (same log) to 165.6 s
  log 3  111,674 frames, armed 0-107.3 s
  Armed in total 368.5 s.

RESULTS
- Released Blackbox 2.3.0 and the updated viewer decode the same field
  lists, frame rows (SHA-256 of all rows) and event-101 strings. 0 corrupt
  frames. Logs 1-3 end with LOG_END. (reports/released-viewer-parity.json)
- FULL header complete in logs 1-3: 496 lines, no long lines, 1324 keys.
  Journal: 0 sequence gaps, 0 CRC errors, 0 incomplete records, Q
  unsent=0 lostrec=0, 0 timeline flags, header/journal self-test OK.
- Transmitter Lua edits, saved between arms:
    log 1 -> 2  p0.yaw_p_gain 65 -> 66
    log 2 -> 3  p0.yaw_p_gain 66 -> 65, p1.yaw_i_gain 116 -> 117
  These are the only header differences between consecutive logs. The
  journal of each next log records them as pre-log reconciliations, for
  example "PC1 p s=v n=1 p0.yaw_p_gain=66<65*8C", and log 3 also has
  pid_profile 1 -> 0. No
  write happened while a log was open, so the records give the values, not
  the Lua write times.
- Controller readback after the run (CLI diff all, not included): the only
  line that differs from the backup before the run is profile 1 yaw_i_gain
  116 -> 117, the net result of the recorded edits.
- 16 PID-profile changes from the adjustment switch while armed and
  spinning (5, 3 and 8 in logs 1-3). Each has its C record (s=a.2), the
  gov/rsc/pid loader records and the runtime fingerprints.
- Arm/disarm: the armed S-field and the DISARM events (reason 4, switch)
  agree. The re-arm in log 2 gives the epochs armed / disarmed / armed in
  the same log. ARM-mode drops of 1-2 RC frames (2-4 ms) are in the log as
  flight-mode events (7 in log 1, 1 in log 2). They did not disarm, because
  rc_controls.c disarms after 4 consecutive RC updates with the switch off.
- Armed frame interval: median 1004-1005 us, max 1028 us, iteration delta
  always 1. Disarmed: one 71-72 ms interval in each log at the EEPROM save
  after disarm (journal M eesave us=69870-70824).
- Receiver: rxSignalReceived, rxFlightChannelsValid and failsafePhase never
  change. rssi 346-800.

HEADER-ONLY LOG 0
The pilot disarmed while the FULL header was being written. Stock
blackboxCheckEnabler moves any header state directly to SHUTTING_DOWN
without LOG_END. The log thus has 18,432 of the 18,625 header bytes and no
frames. Blackbox 2.3.0 shows "Log truncated, no data". Stock 4.6.0 has the
same path, but the FULL header makes the window longer: the arming beep comes
0.400 s before the first frame with FULL (18.6 kB header) and 0.227 s before
it with the stock 3.9 kB header (earlier 4.6 bench logs of this PR).

LIMITS
4.6 backport, not the PR head. Blades off, no flight. FULL mode only, no
CHANGES/OFF Lua edits. No MCU timing or stack measurements.

FILES
logs/       the recording
reports/    journal.txt (per log: header, header differences, arm and
            profile transitions, every journal record), frames.json
            (frame and event statistics), released-viewer-parity.json
SHA256SUMS  shasum -a 256 -c SHA256SUMS
