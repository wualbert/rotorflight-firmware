FIREBALL HARDWARE EVIDENCE FOR THE PARAMETER-JOURNAL PR

Scope: stationary bench session on 2026-10-13, STM32G47X / MTKS-MATEKG474HELI.
Candidate firmware: 4.6.0-bbp-bench, commit 874f369d5274270a74a87d439921bfbfaa53df44.
The stock baseline is Rotorflight 4.6.0 (118e912).

These logs predate the rebase onto 4.7 master. They DO NOT validate PR head
430bc337de87a11eccf673d0bf7155c7a2df0663. New bench and flight tests remain pending.

Files: stock baseline, candidate OFF, and three independent candidate FULL logs.
All five BBL files are byte-for-byte copies of the original verified USB downloads.
Each contains one recording. The manifest records original paths, SHA-256 and counts.
Historical flights and complete CLI configuration backups remain in the private archive.

FULL log   Active PID   Yaw P in profiles 1 / 2 / 3   Main frames
A          1            65 / 45 / 40                   13351
B          1            66 / 45 / 40                   12220
C          3            65 / 45 / 41                   17440

Each FULL header was checked against all 612 PID and 192 rate values, covering
all six PID and six rate slots. Actual transmitter Lua changes were profile 1
yaw P 65 -> 66 -> 65 and profile 3 yaw P 40 -> 41. Source-v reconciliation records
establish the values, not the exact time of a preceding Lua write.

Released Blackbox 2.3.0 and the updated decoder agree on all 130141 main frames
and all slow frames across the five recordings. Every log ends normally; there
are zero invalid/corrupt frames. Released 2.3.0 does not interpret parameter history.
All five files previously passed independent complete USB readback comparison.
The gains were restored after this session; see the configuration-restored report.

Run `shasum -a 256 -c SHA256SUMS` from this extracted directory to verify contents.
Open logs/*.bbl in Blackbox to inspect the individual recordings. The original
compatibility report uses date-suffixed filenames; match records by SHA-256.

No flight test or MCU timing/stack bound is established here. Remaining bench
coverage is listed in reports/all-profiles-result.json. No PR is published by
preparing this attachment.
