ROTORFLIGHT PARAMETER-JOURNAL HARDWARE EVIDENCE

PR head: 430bc337de87a11eccf673d0bf7155c7a2df0663
Installed production code: 85d7049a9377af53b1ce9564248139d9ceb854c1
The second PR commit changes validation tooling only.
Hardware: SAB Fireball / STM32G47X / MTKS-MATEKG474HELI.

FINAL RESULT: the stationary FULL-mode core bench checks passed.
Seven original recordings, 154113 main frames, reports and SHA-256 checksums
are included. The new 4.7 results and the earlier 4.6 results are separated.

CURRENT 4.7 RECORDINGS
- full-a: baseline, active PID profile 1, yaw P 65/45/40/80/80/80.
  16094 main frames; complete 501-line FULL header, hash 9a928457.
- full-b: actual transmitter Lua saves set yaw P to 66/46/41 in profiles
  1/2/3; a separate short arm cycle records active PID profile 2.
  7878 main frames; complete 501-line FULL header, hash 4b7cb5b8.

Each new log independently verifies all 624 PID and 192 rate setting values
across all six PID and six rate slots, including inactive slots. The only
profile-value differences between the two headers are the three intended yaw
P edits. B also records all three changes and the PID selection change as
pre-log value reconciliations. These records establish the values, not exact
Lua write times; the user-confirmed Lua actions and live MSP observations
establish the transmitter path. The old header is retained in the first log;
the next new log has the updated header.

Both new downloads were read back independently twice with identical bytes.
All main/slow frames and field schemas decode identically with released
Blackbox 2.3.0. There are no corrupt/invalid frames, missing iterations,
journal CRC errors, sequence gaps, or unsent/lost records; each has LOG_END.
Motor output and throttle remain zero throughout. B contains a 72.629 ms
frame interval during a disarmed EEPROM save, without missing iterations.
The armed frame-interval maximum is 1.024 ms in A and 1.022 ms in B; these
observations do not establish MCU execution-time bounds or stack headroom.

CLEANUP AND CONFIGURATION
Firmware readback and a compatible complete configuration restore passed.
The restored configuration also passed a full battery/USB power cycle before
the arm tests. After testing, yaw P was restored to 65/45/40/80/80/80, saved,
and read back after reboot. All 1208 settings, 447 other configuration
commands, and board defaults match the pre-test configuration. The receiver
switch currently selects PID profile 2 (yaw P 45); rate profile 1 is active.
The final controller status was disarmed with throttle/ARM low and no arming
inhibit. No further arm cycles are needed for these core checks.

EARLIER 4.6 EVIDENCE
legacy-4.6 preserves five earlier stationary stock/OFF/FULL recordings and
their reports (130141 frames) from 874f369d5 and the stock 4.6 baseline.
Their results apply to those revisions. All original files are unchanged.

USE AND LIMITS
Extract this archive and run: shasum -a 256 -c SHA256SUMS
Open the logs/*.bbl files in Blackbox. Released 2.3.0 decodes the main/slow
frames; parameter-history interpretation requires the updated viewer. The
4.7 runtime consumer checks cover a reviewed subset, while the header
comparison independently checks all 816 profile values in each new log.
Decoder parity does not constitute an interactive GUI test.

CHANGES/OFF Lua hardware cases, rate switching, grace-window rearm, physical
storage/radio faults, precise MCU timing/stack measurements, and flight tests
remain outside this 4.7 hardware run. This is stationary core bench evidence,
not full hardware acceptance or flight validation. Existing Docker coverage
is recorded separately in the PR validation report.

current-4.7/reports/CORE_BENCH_RESULT.json is the final current-revision result.
Earlier preflight reports retain their capture-time state; the final result
supersedes their pending-test statements. Raw FC dates are unreliable (A
differs from host time; B is unset); use host metadata and relative frame times.

All BBLs are byte-identical to their original downloads. No historical flight
recordings, full CLI dumps, MCU recovery images, or USB device identifiers
are included. Controller parameters in the original BBL headers are retained.
Full private backups are saved separately and should not be attached publicly.
